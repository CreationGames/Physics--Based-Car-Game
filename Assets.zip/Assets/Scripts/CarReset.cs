﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarReset : MonoBehaviour
{
    public Transform reset;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            transform.rotation = reset.rotation;
        }
    }
}
