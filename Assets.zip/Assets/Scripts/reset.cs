﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
    

public class reset : MonoBehaviour
{
    public string Scene;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Reset"))
        {
             SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
        
    }
}
